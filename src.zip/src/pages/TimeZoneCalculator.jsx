import { useEffect, useState } from "react";
import ClockDisplay from "@/components/time/ClockDisplay";
import TimeZoneInput from "@/components/forms/TimeZoneInput";
import Card from "@/components/ui/Card";
import { Switch } from "@/components/ui/switch";
// import StaticTimePickerLandscape from "./StaticTimePickerLandscape";
import { timeZones } from "@/constants/timeZones"


function TimeZone() {
  const [date, setDate] = useState(new Date());
  const [is12Hours, setIs12Hours] = useState(false);
  const [customTime, setCustomTime] = useState(null);

  const displayDate = customTime ?? date;

  useEffect(() => {
    const timer = setInterval(() => {
      setDate(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const localTimeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;

  function getTime(timeZone) {
    const parts = new Intl.DateTimeFormat("en-GB", {
      timeZone,
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false,
    }).formatToParts(displayDate);

    const get = (type) => parts.find((p) => p.type === type)?.value;

    const hour24 = Number(get("hour"));

    return {
      hour: is12Hours ? hour24 % 12 || 12 : hour24,

      minute: get("minute"),
      second: get("second"),

      period: is12Hours ? (hour24 >= 12 ? "PM" : "AM") : "",

      weekday: new Intl.DateTimeFormat("en-US", {
        timeZone,
        weekday: "long",
      }).format(displayDate),

      isDay: hour24 >= 6 && hour24 < 18,
    };
  }

  function getTimeZoneOffset(timeZone) {
    const parts = new Intl.DateTimeFormat("en-US", {
      timeZone,
      timeZoneName: "shortOffset",
    }).formatToParts(displayDate);

    return (
      parts
        .find((p) => p.type === "timeZoneName")
        ?.value.replace("GMT", "UTC") || "UTC"
    );
  }

  function getDifference(timeZone) {
    const localHour = Number(
      new Intl.DateTimeFormat("en-US", {
        timeZone: localTimeZone,
        hour: "numeric",
        hour12: false,
      }).format(displayDate),
    );

    const zoneHour = Number(
      new Intl.DateTimeFormat("en-US", {
        timeZone,
        hour: "numeric",
        hour12: false,
      }).format(displayDate),
    );

    const diff = zoneHour - localHour;

    return diff >= 0 ? `+${diff}h` : `${diff}h`;
  }

  const zones = [
    {
      city: "My Time Zone",
      zone: localTimeZone,
      isLocal: true,
    },

    ...timeZones.filter((item) => item.zone !== localTimeZone),
  ];

  return (
    <div className="flex flex-col gap-4">
      <Card>
        {/* <StaticTimePickerLandscape /> */}
        <div className="flex flex-col gap-4">
          <div className="text-center">
            <h2 className="text-xl font-bold">World Clock</h2>

            <p className="text-sm text-gray-400">
              Check the current time around the world.
            </p>
          </div>

          <TimeZoneInput setCustomTime={setCustomTime} />

          <div className="flex justify-center items-center gap-3">
            <span
              className={!is12Hours ? "font-bold text-lg" : "text-gray-500"}
            >
              24h
            </span>

            <Switch checked={is12Hours} onCheckedChange={setIs12Hours} />

            <span className={is12Hours ? "font-bold text-lg" : "text-gray-500"}>
              12h
            </span>
          </div>
        </div>
      </Card>

      <section
        className="
        grid
        grid-cols-1
        md:grid-cols-2
        gap-4
      "
      >
        {zones.map((item) => {
          const time = getTime(item.zone);

          return (
            <Card key={item.zone}>
              <div className="flex flex-col gap-3 text-center">
                <div>
                  <h2 className="text-xl font-bold">{item.city}</h2>

                  <p className="text-sm text-gray-400">
                    {item.zone} ({getTimeZoneOffset(item.zone)})
                  </p>
                </div>

                <div className="flex justify-center">
                  <Card className="w-fit">
                    <ClockDisplay time={time} />
                  </Card>
                </div>

                <p className="text-sm text-gray-400">
                  {time.weekday} {getDifference(item.zone)}
                  <span className="ml-1 text-xs">(from you)</span>
                </p>
              </div>
            </Card>
          );
        })}
      </section>
    </div>
  );
}

export default TimeZone;
