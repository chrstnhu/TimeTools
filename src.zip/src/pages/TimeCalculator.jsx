import { useState } from "react";
import Card from "@/components/ui/Card";
import { secondsToTime } from "@/utils/secondsToTime";
import TimeInput from "@/components/forms/TimeInput";
import CalculatorButtons from "@/components/calculator/CalculatorButtons";

function TimeCalculator() {
  const initialResult = {
    total: {
      h: 0,
      m: 0,
      s: 0,
    },
    days: {
      d: 0,
      h: 0,
      m: 0,
      s: 0,
    },
  };

  const [time1, setTime1] = useState({ h: 0, m: 0, s: 0 });
  const [time2, setTime2] = useState({ h: 0, m: 0, s: 0 });
  const [result, setResult] = useState(initialResult);
  const [hasResult, setHasResult] = useState(false);

  const handleCalculate = (selectedOperation) => {
    const seconds1 = time1.h * 3600 + time1.m * 60 + time1.s;
    const seconds2 = time2.h * 3600 + time2.m * 60 + time2.s;

    let totalSeconds;
    if (selectedOperation === "+") {
      totalSeconds = seconds1 + seconds2;
    } else if (selectedOperation === "-") {
      totalSeconds = seconds1 - seconds2;
    }

    totalSeconds = Math.max(0, totalSeconds);

    setHasResult(true);
    setResult(secondsToTime(totalSeconds));
  };

  const handleReset = () => {
    setTime1({ h: 0, m: 0, s: 0 });
    setTime2({ h: 0, m: 0, s: 0 });
    setHasResult(false);
    setResult(initialResult);
  };

  const handleKeep = () => {
    setTime1(result.total);
    setTime2({ h: 0, m: 0, s: 0 });
    setResult(initialResult);
  };

  return (
    <div className="flex flex-col gap-4">
      <Card>
        <div>
          <TimeInput
            label="First time"
            id="time1"
            value={time1}
            onChange={setTime1}
            maxHours={999}
          />

          <div className="flex items-center gap-3">
            <div className="flex-1 h-px bg-[var(--foreground)]/20"></div>
            <span className="text-gray-400 font-bold text-lg">+</span>
            <div className="flex-1 h-px bg-[var(--foreground)]/20"></div>
          </div>

          <TimeInput
            label="Second time"
            id="time2"
            value={time2}
            onChange={setTime2}
            maxHours={999}
          />

          <CalculatorButtons
            onAdd={() => handleCalculate("+")}
            onSubtract={() => handleCalculate("-")}
            onReset={handleReset}
            onKeep={handleKeep}
          />
        </div>
      </Card>

      {hasResult && (
        <Card>
          <h2 className="text-xl font-bold mb-4">Result</h2>

          <Card className="text-center">
            <p className="text-3xl font-bold tracking-wider">
              {result.total.h}h {String(result.total.m).padStart(2, "0")}m{" "}
              {String(result.total.s).padStart(2, "0")}s
            </p>
          </Card>

          <div className="mt-6">
            <p className="font-semibold mb-2">Equivalent</p>
            <div className="grid grid-cols-4 gap-3">
              <Card>
                <p className="text-sm text-gray-400">Days</p>
                <p className="text-xl">{result.days.d}</p>
              </Card>

              <Card>
                <p className="text-sm text-gray-400">Hours</p>
                <p className="text-xl">{result.days.h}</p>
              </Card>

              <Card>
                <p className="text-sm text-gray-400">Minutes</p>
                <p className="text-xl">{result.days.m}</p>
              </Card>

              <Card>
                <p className="text-sm text-gray-400">Seconds</p>
                <p className="text-xl">{result.days.s}</p>
              </Card>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}

export default TimeCalculator;
