function Card({ children, className = "" }) {
  return (
    <div
      className={`
        max-w-full
        p-2
        text-center
        rounded-lg
        font-medium
        transition
        shadow-md
        text-[var(--text)]
        hover:shadow-lg
        ring-1 
        ring-[var(--foreground)]/10
        bg-[var(--background)]/80
        ${className}
      `}
    >
      {children}
    </div>
  );
}

export default Card;
